SSID = "KMD652_Group_2"
PASSWORD = "Xia0/wan9"
BROKER_IP = 'anluke.asuscomm.com'
